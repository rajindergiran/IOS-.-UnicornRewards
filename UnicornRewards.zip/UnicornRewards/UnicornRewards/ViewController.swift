//
//  ViewController.swift
//  UnicornRewards
//
//  Created by robin on 2017-11-07.
//  Copyright © 2017 robin. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // ==================================
    // SUBMITTED BY:
    //Rajinder Singh Giran     C0705279
   
    // ==================================
    
    
    // outlets
    
    @IBOutlet weak var lblpoints: UILabel!
    @IBOutlet weak var switchten: UISwitch!
    
    @IBOutlet weak var switchtwenty: UISwitch!
    
    @IBOutlet weak var swithseven: UISwitch!
    // variables
    
    // actions

    @IBAction func btnresult(_ sender: UIButton) {
        if( switchten.isOn && switchtwenty.isOn && swithseven.isOn == true){
            lblpoints.text = "Total Reward Points: 105pts"
        }
        else if(switchten.isOn && switchtwenty.isOn == true){
           lblpoints.text = "Total Reward Points:  30pts"
        }
        else if(switchten.isOn && swithseven.isOn == true){
             lblpoints.text = "Total Reward Points:  85pts"
        }
        else if(switchtwenty.isOn && swithseven.isOn == true){
            lblpoints.text = "Total Reward Points:  95pts"
        }
        else if(switchten.isOn == true){
            lblpoints.text = "Total Reward Points: 10pts"

        }
        else if(switchtwenty.isOn == true){
            lblpoints.text = "Total Reward Points: 20pts"

        }
        else if(swithseven.isOn  == true){
            lblpoints.text = "Total Reward Points: 75pts"

        }
        else{
            lblpoints.text = "Total Reward Points: 105pt"

        }
    }
    
    @IBAction func btnrewardtf(_ sender: UIButton) {
        if( switchten.isOn && switchtwenty.isOn && swithseven.isOn == true){
            lblpoints.text = "Total Reward Points: 85pts"
        }
        else if(switchten.isOn && switchtwenty.isOn == true){
            lblpoints.text = "Total Reward Points:  5pts"
        }
        else if(switchten.isOn && swithseven.isOn == true){
            lblpoints.text = "Total Reward Points:  50pts"
        }
        else if(switchtwenty.isOn && swithseven.isOn == true){
            lblpoints.text = "Total Reward Points:  70pts"
        }
        else if(switchten.isOn == true){
            lblpoints.text = "Not Enough points"
            
        }
        else if(switchtwenty.isOn == true){
            lblpoints.text = "Not Enough points"
            
        }
        else if(swithseven.isOn  == true){
            lblpoints.text = "Total Reward Points: 50pts"
            
        }
        else{
            lblpoints.text = "Not Enough points"
            
        }
    }
    
    @IBAction func btnhundered(_ sender: UIButton) {
        if( switchten.isOn && switchtwenty.isOn && swithseven.isOn == true){
            lblpoints.text = "Total Reward Points: 5"
        }
        else if(switchten.isOn && switchtwenty.isOn == true){
            lblpoints.text = "Not Enough points"
        }
        else if(switchten.isOn && swithseven.isOn == true){
            lblpoints.text = "Not Enough points"
        }
        else if(switchtwenty.isOn && swithseven.isOn == true){
            lblpoints.text = "Not Enough points"
        }
        else if(switchten.isOn == true){
            lblpoints.text = "Not Enough points"
            
        }
        else if(switchtwenty.isOn == true){
            lblpoints.text = "Not Enough points"
            
        }
        else if(swithseven.isOn  == true){
            lblpoints.text = "Not Enough points"
            
        }
        else{
            lblpoints.text = "Not Enough points"
            
        }
    }
    }

